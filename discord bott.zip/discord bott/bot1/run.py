import sys
import os
import subprocess
import shutil
import importlib.util
import tkinter as tk
from tkinter import messagebox

def show_error(title, message):
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror(title, message)
    root.destroy()

def show_info(title, message):
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo(title, message)
    root.destroy()

def check_chrome():
    chrome_paths = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    ]
    for path in chrome_paths:
        if os.path.exists(path):
            return True
    if shutil.which("chrome") or shutil.which("chrome.exe"):
        return True
    return False

def pre_flight_checks():
    if not check_chrome():
        show_error(
            "Chrome Not Found",
            "Google Chrome is required but not installed.\n\n"
            "Please install Chrome from:\n"
            "https://www.google.com/chrome/\n\n"
            "Then restart this program."
        )
        return False
    return True

def import_main_dynamically():
    
    try:
        import main as main_module  
        if hasattr(main_module, "main"):
            return getattr(main_module, "main")
    except Exception:
        pass

    
    search_paths = []
    
    search_paths.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "main.py"))
    
    if hasattr(sys, '_MEIPASS'):
        search_paths.append(os.path.join(sys._MEIPASS, "main.py"))
    
    search_paths.append(os.path.join(os.getcwd(), "main.py"))
    for fpath in search_paths:
        if os.path.exists(fpath):
            try:
                spec = importlib.util.spec_from_file_location("main", fpath)
                main_mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(main_mod)
                return main_mod.main
            except Exception as e:
                show_error("Startup Error", f"main.py found but import failed:\n{e}")
                sys.exit(1)
    show_error("Startup Error", "main.py was not found in any known location.\n"
                                "Please contact Steve for support.")
    sys.exit(1)

def main():
    if not pre_flight_checks():
        sys.exit(1)
    try:
        app_main = import_main_dynamically()
        app_main()
    except Exception as e:
        show_error(
            "Application Error",
            f"An error occurred while starting the tool:\n{e}\n\n"
            "Please contact Steve and send him this error message."
        )
        sys.exit(1)

if __name__ == "__main__":
    main()
