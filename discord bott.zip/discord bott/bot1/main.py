#!/usr/bin/env python3
"""
MS Account Password Changer - Discord Bot
Stays in Discord + sends detailed logs
Owner ID: 1421209611901341929
"""

import discord
from discord.ext import commands
import os
import json
import asyncio
import io
import sys
from datetime import datetime
from typing import List, Dict, Optional
import traceback

# ============================================
# CONFIGURATION
# ============================================

TOKEN = 'YOUR_BOT_TOKEN_HERE'
SUPER_USER_ID = 1421209611901341929  # Your Discord ID
PREFIX = '&'
MAX_ACCOUNTS_PER_USER = 15
AUTH_FILE = 'authorized_users.json'

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

# Data storage
user_sessions = {}
authorized_users = set()

class ProcessingSession:
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.accounts = []
        self.current_index = 0
        self.auto_generate = True
        self.captcha_data = None
        self.status = "idle"
        self.captcha_solution = None
        self.driver = None
        self.screenshot_count = 0
        self.current_message = None
        self.current_step = "Starting"
        self.logs = []  # Store step-by-step logs
    
    def add_account(self, email: str, password: str):
        self.accounts.append({
            'email': email,
            'password': password,
            'new_password': None,
            'status': 'pending',
            'result': None,
            'captcha_attempts': 0,
            'logs': []
        })
    
    def set_new_password(self, index: int, password: str):
        if 0 <= index < len(self.accounts):
            self.accounts[index]['new_password'] = password
    
    def update_status(self, index: int, status: str, result=None):
        if 0 <= index < len(self.accounts):
            self.accounts[index]['status'] = status
            if result:
                self.accounts[index]['result'] = result
    
    def add_log(self, index: int, step: str, details: str, success: bool = True):
        if 0 <= index < len(self.accounts):
            timestamp = datetime.now()
            log_entry = {
                'step': step,
                'details': details,
                'success': success,
                'timestamp': timestamp.isoformat(),
                'time_str': timestamp.strftime('%H:%M:%S')
            }
            self.accounts[index]['logs'].append(log_entry)
            self.logs.append(f"[{timestamp.strftime('%H:%M:%S')}] {step}: {details}")
            return log_entry
        return None
    
    def increment_captcha_attempts(self, index: int):
        if 0 <= index < len(self.accounts):
            self.accounts[index]['captcha_attempts'] += 1
            return self.accounts[index]['captcha_attempts']
        return 0

def save_authorized_users():
    with open(AUTH_FILE, 'w') as f:
        json.dump(list(authorized_users), f)

def load_authorized_users():
    global authorized_users
    try:
        if os.path.exists(AUTH_FILE):
            with open(AUTH_FILE, 'r') as f:
                authorized_users = set(json.load(f))
    except:
        authorized_users = set()
        save_authorized_users()

def is_super_user(ctx):
    return ctx.author.id == SUPER_USER_ID

def is_authorized():
    async def predicate(ctx):
        if ctx.author.id == SUPER_USER_ID:
            return True
        if ctx.author.id in authorized_users:
            return True
        await ctx.send(
            f"❌ Not authorized. Ask <@{SUPER_USER_ID}> to use `{PREFIX}auth @yourname`",
            ephemeral=True
        )
        return False
    return commands.check(predicate)

@bot.event
async def on_ready():
    load_authorized_users()
    print(f'✅ Bot online! Owner ID: {SUPER_USER_ID}')
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching,
        name="Microsoft Accounts | &help"
    ))

# ============================================
# SCREENSHOT COMMAND (&ss)
# ============================================

@bot.command(name='ss')
@is_authorized()
async def take_screenshot(ctx, *, description: str = None):
    """Take manual screenshot of current browser"""
    
    if ctx.author.id not in user_sessions:
        await ctx.send("❌ No active processing session.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if not session.driver:
        await ctx.send("❌ No browser session active.")
        return
    
    if session.status not in ['processing', 'waiting_captcha']:
        await ctx.send("❌ Can only take screenshots during active processing.")
        return
    
    try:
        # Take screenshot
        screenshot_bytes = session.driver.get_screenshot_as_png()
        
        if not screenshot_bytes:
            await ctx.send("❌ Failed to capture screenshot.")
            return
        
        # Increment counter
        session.screenshot_count += 1
        
        # Create filename
        timestamp = datetime.now().strftime('%H%M%S')
        filename = f"ss_{ctx.author.id}_{timestamp}.png"
        
        # Send to Discord
        file = discord.File(io.BytesIO(screenshot_bytes), filename=filename)
        
        embed = discord.Embed(
            title="📸 Manual Screenshot",
            description="Screenshot taken manually while processing",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if session.accounts and session.current_index < len(session.accounts):
            current_acc = session.accounts[session.current_index]
            embed.add_field(name="Account", value=f"`{current_acc['email'][:20]}...`", inline=True)
            embed.add_field(name="Current Step", value=session.current_step, inline=True)
        
        if description:
            embed.add_field(name="Description", value=description, inline=False)
        
        embed.set_footer(text=f"User: {ctx.author.name} | Screenshot #{session.screenshot_count}")
        
        await ctx.send(embed=embed, file=file)
        
    except Exception as e:
        await ctx.send(f"❌ Screenshot error: {str(e)[:100]}")
        print(f"Screenshot error: {e}")

# ============================================
# LOG COMMANDS
# ============================================

@bot.command(name='logs')
@is_authorized()
async def show_logs(ctx, account_number: int = None):
    """Show logs for current account or specific account"""
    
    if ctx.author.id not in user_sessions:
        await ctx.send("❌ No active session.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if account_number is None:
        # Show logs for current account
        index = session.current_index
        if index >= len(session.accounts):
            await ctx.send("❌ No current account.")
            return
    else:
        # Show logs for specific account
        index = account_number - 1
        if index < 0 or index >= len(session.accounts):
            await ctx.send(f"❌ Invalid account number (1-{len(session.accounts)})")
            return
    
    account = session.accounts[index]
    logs = account.get('logs', [])
    
    if not logs:
        embed = discord.Embed(
            title=f"📝 Logs for Account #{index+1}",
            description=f"`{account['email']}`",
            color=discord.Color.blue()
        )
        embed.add_field(name="No Logs", value="Processing hasn't started for this account yet.", inline=False)
        await ctx.send(embed=embed)
        return
    
    # Create paginated logs
    page_size = 10
    total_pages = (len(logs) + page_size - 1) // page_size
    
    # Show first page by default
    page = 1
    start_idx = (page - 1) * page_size
    end_idx = min(start_idx + page_size, len(logs))
    
    embed = discord.Embed(
        title=f"📝 Logs for Account #{index+1}",
        description=f"`{account['email']}`",
        color=discord.Color.blue()
    )
    embed.add_field(name="Status", value=account['status'].title(), inline=True)
    embed.add_field(name="Total Logs", value=len(logs), inline=True)
    
    # Add log entries
    log_text = ""
    for i in range(start_idx, end_idx):
        log = logs[i]
        status = "✅" if log['success'] else "❌"
        log_text += f"{status} **{log['step']}** ({log['time_str']})\n"
        log_text += f"   ↳ {log['details'][:100]}\n\n"
    
    if log_text:
        embed.add_field(name=f"Logs (Page {page}/{total_pages})", value=log_text, inline=False)
    
    if total_pages > 1:
        embed.set_footer(text=f"Use &logs {account_number} [page] to see more")
    
    await ctx.send(embed=embed)

@bot.command(name='lastlog')
@is_authorized()
async def show_last_log(ctx, count: int = 5):
    """Show last N log entries from current processing"""
    
    if ctx.author.id not in user_sessions:
        await ctx.send("❌ No active session.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if not session.logs:
        await ctx.send("📭 No logs yet.")
        return
    
    embed = discord.Embed(
        title="📝 Recent Logs",
        color=discord.Color.blue()
    )
    
    # Get last N logs
    recent_logs = session.logs[-min(count, 20):]  # Max 20
    
    log_text = ""
    for log in recent_logs:
        log_text += f"{log}\n"
    
    embed.add_field(name=f"Last {len(recent_logs)} Entries", value=log_text[:1000], inline=False)
    
    if session.accounts and session.current_index < len(session.accounts):
        current_acc = session.accounts[session.current_index]
        embed.add_field(name="Current Account", value=f"`{current_acc['email']}`", inline=True)
    
    embed.add_field(name="Current Step", value=session.current_step, inline=True)
    
    await ctx.send(embed=embed)

# ============================================
# AUTH COMMANDS
# ============================================

@bot.command(name='auth')
async def authorize_user(ctx, user: discord.User = None):
    """Authorize a user to use the bot (Owner only)"""
    if not is_super_user(ctx):
        await ctx.send("❌ Only the owner can authorize users.", ephemeral=True)
        return
    
    if not user:
        await ctx.send(f"❌ Usage: `{PREFIX}auth @username`", ephemeral=True)
        return
    
    if user.id == SUPER_USER_ID:
        await ctx.send("🤨 The owner is already authorized.", ephemeral=True)
        return
    
    if user.id in authorized_users:
        await ctx.send(f"✅ {user.mention} is already authorized.", ephemeral=True)
        return
    
    authorized_users.add(user.id)
    save_authorized_users()
    
    embed = discord.Embed(
        title="✅ User Authorized",
        description=f"{user.mention} can now use the bot",
        color=discord.Color.green()
    )
    embed.add_field(name="Authorized By", value=ctx.author.mention, inline=True)
    embed.add_field(name="Total Authorized", value=len(authorized_users), inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='unauth')
async def unauthorize_user(ctx, user: discord.User = None):
    """Remove a user's authorization (Owner only)"""
    if not is_super_user(ctx):
        await ctx.send("❌ Only the owner can unauthorize users.", ephemeral=True)
        return
    
    if not user:
        await ctx.send(f"❌ Usage: `{PREFIX}unauth @username`", ephemeral=True)
        return
    
    if user.id == SUPER_USER_ID:
        await ctx.send("😠 You cannot unauthorize the owner!", ephemeral=True)
        return
    
    if user.id not in authorized_users:
        await ctx.send(f"❌ {user.mention} is not authorized.", ephemeral=True)
        return
    
    authorized_users.remove(user.id)
    save_authorized_users()
    
    if user.id in user_sessions:
        del user_sessions[user.id]
    
    embed = discord.Embed(
        title="❌ User Unauthorized",
        description=f"{user.mention} can no longer use the bot",
        color=discord.Color.red()
    )
    embed.add_field(name="Removed By", value=ctx.author.mention, inline=True)
    embed.add_field(name="Total Authorized", value=len(authorized_users), inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='authlist')
async def list_authorized(ctx):
    """List all authorized users (Owner only)"""
    if not is_super_user(ctx):
        await ctx.send("❌ Only the owner can view the authorized list.", ephemeral=True)
        return
    
    if not authorized_users:
        await ctx.send("📭 No users are authorized (except the owner).", ephemeral=True)
        return
    
    embed = discord.Embed(
        title="👥 Authorized Users",
        color=discord.Color.blue()
    )
    
    user_list = []
    for user_id in authorized_users:
        user = bot.get_user(user_id)
        if user:
            user_list.append(f"{user.mention} (`{user.id}`)")
        else:
            user_list.append(f"`{user_id}` (User not found)")
    
    embed.add_field(
        name=f"Users ({len(authorized_users)})",
        value="\n".join(user_list) or "None",
        inline=False
    )
    
    embed.set_footer(text=f"Owner: <@{SUPER_USER_ID}>")
    await ctx.send(embed=embed, ephemeral=True)

# ============================================
# ACCOUNT MANAGEMENT
# ============================================

@bot.command(name='add')
@is_authorized()
async def add_account(ctx, *, account_data: str):
    """Add a single account (format: email:password)"""
    if ':' not in account_data:
        await ctx.send("❌ Invalid format. Use: `email:password`")
        return
    
    email, password = account_data.split(':', 1)
    email = email.strip()
    password = password.strip()
    
    if ctx.author.id not in user_sessions:
        user_sessions[ctx.author.id] = ProcessingSession(ctx.author.id)
    
    session = user_sessions[ctx.author.id]
    
    if len(session.accounts) >= MAX_ACCOUNTS_PER_USER:
        await ctx.send(f"❌ Maximum {MAX_ACCOUNTS_PER_USER} accounts per user.")
        return
    
    session.add_account(email, password)
    
    embed = discord.Embed(
        title="✅ Account Added",
        description=f"Added account to processing queue",
        color=discord.Color.green()
    )
    embed.add_field(name="Email", value=f"`{email}`", inline=False)
    embed.add_field(name="Queue Position", value=f"#{len(session.accounts)}", inline=True)
    embed.add_field(name="Total Accounts", value=len(session.accounts), inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='addfile')
@is_authorized()
async def add_file(ctx):
    """Upload accounts.txt file"""
    if not ctx.message.attachments:
        await ctx.send("❌ Please attach an accounts.txt file")
        return
    
    attachment = ctx.message.attachments[0]
    if not attachment.filename.endswith('.txt'):
        await ctx.send("❌ Please upload a .txt file")
        return
    
    content = await attachment.read()
    content = content.decode('utf-8')
    
    if ctx.author.id not in user_sessions:
        user_sessions[ctx.author.id] = ProcessingSession(ctx.author.id)
    
    session = user_sessions[ctx.author.id]
    added = 0
    errors = 0
    
    for line_num, line in enumerate(content.splitlines(), 1):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        
        if ':' not in line:
            errors += 1
            continue
        
        if len(session.accounts) >= MAX_ACCOUNTS_PER_USER:
            break
        
        email, password = line.split(':', 1)
        session.add_account(email.strip(), password.strip())
        added += 1
    
    embed = discord.Embed(
        title="📁 File Upload Complete",
        color=discord.Color.blue()
    )
    embed.add_field(name="Accounts Added", value=added, inline=True)
    embed.add_field(name="Errors", value=errors, inline=True)
    embed.add_field(name="Total in Queue", value=len(session.accounts), inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='list')
@is_authorized()
async def list_accounts(ctx):
    """List all accounts in queue"""
    if ctx.author.id not in user_sessions or not user_sessions[ctx.author.id].accounts:
        await ctx.send("📭 No accounts in queue.")
        return
    
    session = user_sessions[ctx.author.id]
    
    embed = discord.Embed(
        title=f"📋 Accounts Queue ({len(session.accounts)})",
        color=discord.Color.blue()
    )
    
    for i, acc in enumerate(session.accounts, 1):
        status_emoji = {
            'pending': '⏳',
            'processing': '🔄',
            'success': '✅',
            'failed': '❌',
            'waiting_captcha': '🖼️'
        }.get(acc['status'], '❓')
        
        log_count = len(acc.get('logs', []))
        log_text = f" | 📝{log_count}" if log_count > 0 else ""
        
        embed.add_field(
            name=f"{status_emoji} Account #{i}",
            value=f"**Email:** `{acc['email']}`\n**Status:** {acc['status'].title()}{log_text}",
            inline=False
        )
    
    await ctx.send(embed=embed)

@bot.command(name='clear')
@is_authorized()
async def clear_accounts(ctx):
    """Clear all accounts from queue"""
    if ctx.author.id not in user_sessions:
        await ctx.send("📭 No accounts to clear.")
        return
    
    count = len(user_sessions[ctx.author.id].accounts)
    user_sessions[ctx.author.id] = ProcessingSession(ctx.author.id)
    
    await ctx.send(f"🗑️ Cleared {count} account(s) from queue.")

# ============================================
# PROCESSING WITH DETAILED LOGS
# ============================================

@bot.command(name='password')
@is_authorized()
async def set_password_mode(ctx, mode: str):
    """Set password generation mode (auto or manual)"""
    if ctx.author.id not in user_sessions:
        user_sessions[ctx.author.id] = ProcessingSession(ctx.author.id)
    
    session = user_sessions[ctx.author.id]
    
    if mode.lower() == 'auto':
        session.auto_generate = True
        await ctx.send("✅ Password mode set to **Auto-generate** (ShulkerGen######)")
    elif mode.lower() == 'manual':
        session.auto_generate = False
        await ctx.send("✅ Password mode set to **Manual** (you'll enter passwords)")
    else:
        await ctx.send("❌ Invalid mode. Use `auto` or `manual`")

@bot.command(name='start')
@is_authorized()
async def start_processing(ctx):
    """Start processing accounts with detailed logs"""
    if ctx.author.id not in user_sessions or not user_sessions[ctx.author.id].accounts:
        await ctx.send("❌ No accounts to process. Add accounts first.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if session.status == 'processing':
        await ctx.send("⚠️ Already processing accounts.")
        return
    
    # Start processing in background
    await ctx.send(f"🚀 Starting processing for {len(session.accounts)} account(s)...")
    asyncio.create_task(process_accounts_with_logs(ctx, session))

async def send_step_log(ctx, session, step: str, details: str, success: bool = True, embed_color: discord.Color = None):
    """Send a log message for a processing step"""
    if not embed_color:
        embed_color = discord.Color.green() if success else discord.Color.red()
    
    # Add to session logs
    log_entry = session.add_log(session.current_index, step, details, success)
    
    # Create embed
    embed = discord.Embed(
        title=f"📝 {step}",
        description=details,
        color=embed_color,
        timestamp=datetime.now()
    )
    
    if session.accounts and session.current_index < len(session.accounts):
        current_acc = session.accounts[session.current_index]
        embed.add_field(name="Account", value=f"`{current_acc['email']}`", inline=True)
        embed.add_field(name="Progress", value=f"{session.current_index + 1}/{len(session.accounts)}", inline=True)
    
    status_emoji = "✅" if success else "❌"
    embed.set_footer(text=f"{status_emoji} Step logged at {log_entry['time_str']}")
    
    await ctx.send(embed=embed)

async def process_accounts_with_logs(ctx, session: ProcessingSession):
    """Process accounts with detailed logging"""
    session.status = 'processing'
    session.current_index = 0
    
    for i, account in enumerate(session.accounts):
        session.current_index = i
        session.update_status(i, 'processing')
        
        # Send starting log
        await send_step_log(ctx, session, "Starting Account", f"Beginning processing for account {i+1}")
        
        try:
            # Step 1: Determine new password
            session.current_step = "Password Setup"
            if session.auto_generate:
                from utils.password_generator import generate_shulker_password
                new_password = generate_shulker_password()
                session.set_new_password(i, new_password)
                await send_step_log(ctx, session, "Password Generated", f"Generated password: `{new_password}`")
            else:
                await send_step_log(ctx, session, "Manual Password", "Waiting for manual password input...")
                try:
                    dm = await ctx.author.create_dm()
                    await dm.send(f"🔐 Enter password for `{account['email']}`:")
                    
                    def check(m):
                        return m.author == ctx.author and isinstance(m.channel, discord.DMChannel)
                    
                    pw_msg = await bot.wait_for('message', timeout=120, check=check)
                    new_password = pw_msg.content.strip()
                    session.set_new_password(i, new_password)
                    await send_step_log(ctx, session, "Password Received", f"Manual password entered")
                except asyncio.TimeoutError:
                    session.update_status(i, 'failed', 'Password input timeout')
                    await send_step_log(ctx, session, "Password Timeout", "No password received in 2 minutes", False)
                    continue
            
            # Step 2: Scrape account info
            session.current_step = "Scraping Account Info"
            await send_step_log(ctx, session, "Scraping Info", "Attempting to login and scrape account information...")
            
            from automation.core import scrape_account_info
            account_info = scrape_account_info(account['email'], account['password'])
            
            if account_info.get("error"):
                session.update_status(i, 'failed', account_info['error'])
                await send_step_log(ctx, session, "Scraping Failed", f"Error: {account_info['error']}", False)
                continue
            
            await send_step_log(ctx, session, "Scraping Successful", 
                              f"Name: {account_info.get('name', 'N/A')} | "
                              f"Region: {account_info.get('region', 'N/A')} | "
                              f"Gamertag: {account_info.get('gamertag', 'N/A')}")
            
            # Step 3: Submit ACSR form
            session.current_step = "Submitting ACSR Form"
            await send_step_log(ctx, session, "Submitting ACSR", "Filling out account recovery form...")
            
            from automation.acsr import submit_acsr_form
            captcha_img, driver, token, tempmail = submit_acsr_form(account_info)
            
            if not captcha_img:
                session.update_status(i, 'failed', "ACSR form submission failed")
                await send_step_log(ctx, session, "ACSR Failed", "Form submission failed", False)
                continue
            
            # Store driver for screenshots
            session.driver = driver
            
            await send_step_log(ctx, session, "ACSR Submitted", 
                              f"Form submitted successfully. Temp mail: {tempmail}")
            
            # Step 4: CAPTCHA handling
            session.current_step = "CAPTCHA Required"
            captcha_bytes = captcha_img.read()
            session.captcha_data = {
                'image_bytes': captcha_bytes,
                'driver': driver,
                'token': token,
                'tempmail': tempmail,
                'account_info': account_info
            }
            session.update_status(i, 'waiting_captcha')
            
            # Send CAPTCHA image
            captcha_file = discord.File(
                io.BytesIO(captcha_bytes),
                filename=f"captcha_{i}.png"
            )
            
            await send_step_log(ctx, session, "CAPTCHA Ready", "CAPTCHA image generated. Waiting for solution...", 
                              embed_color=discord.Color.orange())
            
            captcha_msg = await ctx.send(file=captcha_file)
            
            # Wait for CAPTCHA solution
            captcha_solution = await wait_for_captcha(ctx, session, 300)
            
            if not captcha_solution:
                session.update_status(i, 'failed', 'CAPTCHA timeout')
                await send_step_log(ctx, session, "CAPTCHA Timeout", "No CAPTCHA solution received in 5 minutes", False)
                continue
            
            # Delete CAPTCHA image
            await captcha_msg.delete()
            
            await send_step_log(ctx, session, "CAPTCHA Solved", f"CAPTCHA entered: `{captcha_solution}`")
            
            # Step 5: Continue ACSR flow
            session.current_step = "Continuing ACSR Flow"
            await send_step_log(ctx, session, "Continuing ACSR", "Processing recovery with CAPTCHA solution...")
            
            from automation.acsr_continue import continue_acsr_flow
            reset_link = continue_acsr_flow(
                driver, account_info, token, captcha_solution, f"discord_{ctx.author.id}_{i}"
            )
            
            # Handle CAPTCHA retry
            retry_count = 0
            max_retries = 3
            while reset_link == "CAPTCHA_RETRY_NEEDED" and retry_count < max_retries:
                retry_count += 1
                attempts = session.increment_captcha_attempts(i)
                
                await send_step_log(ctx, session, "CAPTCHA Retry", 
                                  f"Wrong CAPTCHA - retry {retry_count}/{max_retries}", 
                                  False, discord.Color.orange())
                
                captcha_solution = await wait_for_captcha(ctx, session, 300)
                if not captcha_solution:
                    break
                
                reset_link = continue_acsr_flow(
                    driver, account_info, token,
                    captcha_solution, f"discord_{ctx.author.id}_{i}_retry{retry_count}"
                )
            
            if not reset_link or reset_link in ["CAPTCHA_RETRY_NEEDED", "OTP not received.", "CAPTCHA_DOWNLOAD_FAILED"]:
                session.update_status(i, 'failed', f"Reset link failed: {reset_link}")
                await send_step_log(ctx, session, "Reset Link Failed", f"Error: {reset_link}", False)
                continue
            
            await send_step_log(ctx, session, "Reset Link Obtained", "Password reset link successfully obtained")
            
            # Step 6: Reset password
            session.current_step = "Resetting Password"
            await send_step_log(ctx, session, "Resetting Password", "Changing password with reset link...")
            
            from automation.reset_password import perform_password_reset
            updated_password = perform_password_reset(reset_link, account['email'], new_password)
            
            # Success!
            session.update_status(i, 'success', {
                'new_password': updated_password,
                'old_password': account['password'],
                'account_info': account_info
            })
            
            await send_step_log(ctx, session, "Password Changed", 
                              f"✅ Success! New password: `{updated_password}`", 
                              embed_color=discord.Color.green())
            
            # Wait between accounts
            if i < len(session.accounts) - 1:
                wait_msg = await ctx.send(f"⏱️ Next account in 5 seconds...")
                await asyncio.sleep(5)
                await wait_msg.delete()
                
        except Exception as e:
            session.update_status(i, 'failed', str(e))
            await send_step_log(ctx, session, "Processing Error", f"Unexpected error: {str(e)}", False)
            print(f"Error processing account: {e}")
            traceback.print_exc()
        
        finally:
            # Cleanup driver but keep it alive for manual screenshots
            # We'll keep driver alive until explicitly stopped
            pass
    
    session.status = 'completed'
    
    # Final summary with logs
    successful = [a for a in session.accounts if a['status'] == 'success']
    failed = [a for a in session.accounts if a['status'] == 'failed']
    
    summary = discord.Embed(
        title="📊 Processing Complete",
        color=discord.Color.green() if successful else discord.Color.red()
    )
    summary.add_field(name="✅ Successful", value=len(successful), inline=True)
    summary.add_field(name="❌ Failed", value=len(failed), inline=True)
    summary.add_field(name="📝 Total Logs", value=len(session.logs), inline=True)
    summary.add_field(name="📸 Screenshots Taken", value=session.screenshot_count, inline=True)
    
    # Show last few logs
    if session.logs:
        recent_logs = "\n".join(session.logs[-3:])
        summary.add_field(name="Recent Activity", value=recent_logs, inline=False)
    
    summary.set_footer(text=f"Processing completed at {datetime.now().strftime('%H:%M:%S')}")
    
    await ctx.send(embed=summary)
    await ctx.send("🔍 **Processing complete!** You can still use `&ss` to take screenshots or `&stop` to close browser.")

async def wait_for_captcha(ctx, session, timeout):
    def check(m):
        return (
            m.author.id == ctx.author.id and
            m.channel.id == ctx.channel.id and
            m.content.startswith(f'{PREFIX}captcha ')
        )
    
    try:
        msg = await bot.wait_for('message', timeout=timeout, check=check)
        return msg.content[len(f'{PREFIX}captcha '):].strip()
    except asyncio.TimeoutError:
        return None

# ============================================
# UTILITY COMMANDS
# ============================================

@bot.command(name='captcha')
@is_authorized()
async def solve_captcha(ctx, *, captcha_text: str):
    """Solve a CAPTCHA for current processing"""
    if ctx.author.id not in user_sessions:
        await ctx.send("❌ No active session.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if not session.captcha_data:
        await ctx.send("❌ No CAPTCHA pending.")
        return
    
    session.captcha_solution = captcha_text
    await ctx.send(f"✅ CAPTCHA submitted: `{captcha_text[:15]}...`")

@bot.command(name='status')
@is_authorized()
async def check_status(ctx):
    """Check processing status"""
    if ctx.author.id not in user_sessions:
        await ctx.send("📭 No active session.")
        return
    
    session = user_sessions[ctx.author.id]
    
    status_emoji = {
        'idle': '💤',
        'processing': '🔄',
        'waiting_captcha': '🖼️',
        'completed': '✅'
    }.get(session.status, '❓')
    
    embed = discord.Embed(
        title=f"{status_emoji} Processing Status",
        color=discord.Color.blue()
    )
    
    embed.add_field(name="Status", value=session.status.title(), inline=True)
    embed.add_field(name="Accounts", value=len(session.accounts), inline=True)
    embed.add_field(name="Current Account", value=f"#{session.current_index + 1}", inline=True)
    embed.add_field(name="Current Step", value=session.current_step, inline=True)
    embed.add_field(name="Total Logs", value=len(session.logs), inline=True)
    embed.add_field(name="Screenshots", value=session.screenshot_count, inline=True)
    embed.add_field(name="Driver Active", value="✅ Yes" if session.driver else "❌ No", inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='stop')
@is_authorized()
async def stop_processing(ctx):
    """Stop processing and cleanup"""
    if ctx.author.id not in user_sessions:
        await ctx.send("📭 No session to stop.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if session.driver:
        try:
            session.driver.quit()
            await ctx.send("✅ Browser closed.")
        except:
            pass
        session.driver = None
    
    session.status = 'idle'
    await ctx.send("🛑 Processing stopped. Ready for new commands!")

@bot.command(name='genpass')
@is_authorized()
async def generate_password(ctx, count: int = 5):
    """Generate Shulker passwords"""
    if count > 20:
        count = 20
    
    from utils.password_generator import generate_shulker_password
    passwords = [generate_shulker_password() for _ in range(count)]
    
    embed = discord.Embed(
        title="🔑 Generated Passwords",
        color=discord.Color.green()
    )
    
    password_list = "\n".join([f"`{p}`" for p in passwords])
    embed.add_field(name=f"{count} Passwords", value=password_list, inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='test')
@is_authorized()
async def test_account(ctx, *, account_data: str):
    """Test a single account without changing password"""
    if ':' not in account_data:
        await ctx.send("❌ Invalid format. Use: `email:password`")
        return
    
    email, password = account_data.split(':', 1)
    
    embed = discord.Embed(
        title="🧪 Testing Account",
        description=f"Testing `{email}`",
        color=discord.Color.blue()
    )
    
    msg = await ctx.send(embed=embed)
    
    try:
        embed.add_field(name="Step", value="Scraping account info...", inline=False)
        await msg.edit(embed=embed)
        
        from automation.core import scrape_account_info
        account_info = scrape_account_info(email, password)
        
        if account_info.get("error"):
            embed.color = discord.Color.red()
            embed.add_field(name="❌ Error", value=account_info['error'], inline=False)
        else:
            embed.color = discord.Color.green()
            embed.add_field(name="✅ Success", value="Account is valid!", inline=False)
            embed.add_field(name="Name", value=account_info.get('name', 'N/A'), inline=True)
            embed.add_field(name="Region", value=account_info.get('region', 'N/A'), inline=True)
            embed.add_field(name="Gamertag", value=account_info.get('gamertag', 'N/A'), inline=True)
        
        await msg.edit(embed=embed)
        
    except Exception as e:
        embed.color = discord.Color.red()
        embed.add_field(name="❌ Error", value=str(e), inline=False)
        await msg.edit(embed=embed)

# ============================================
# HELP COMMAND
# ============================================

@bot.command(name='help')
async def help_command(ctx):
    """Show available commands"""
    is_super = ctx.author.id == SUPER_USER_ID
    is_auth = ctx.author.id in authorized_users
    
    embed = discord.Embed(
        title="🔐 MS Account Password Changer",
        description="Stays in Discord with detailed logs",
        color=discord.Color.blue()
    )
    
    embed.add_field(
        name="ℹ️ Basic",
        value=f"`{PREFIX}help` - Show this message",
        inline=False
    )
    
    if is_super:
        embed.add_field(
            name="👑 Owner Commands",
            value=(
                f"`{PREFIX}auth @user` - Authorize user\n"
                f"`{PREFIX}unauth @user` - Remove authorization\n"
                f"`{PREFIX}authlist` - List authorized users"
            ),
            inline=False
        )
    
    if is_super or is_auth:
        embed.add_field(
            name="📋 Account Management",
            value=(
                f"`{PREFIX}add email:pass` - Add account\n"
                f"`{PREFIX}addfile` - Upload accounts.txt\n"
                f"`{PREFIX}list` - Show queue\n"
                f"`{PREFIX}clear` - Clear all\n"
                f"`{PREFIX}password auto/manual` - Set mode"
            ),
            inline=False
        )
        
        embed.add_field(
            name="⚙️ Processing",
            value=(
                f"`{PREFIX}start` - Start with detailed logs\n"
                f"`{PREFIX}status` - Check status\n"
                f"`{PREFIX}captcha TEXT` - Solve CAPTCHA\n"
                f"`{PREFIX}stop` - Stop processing\n"
                f"`{PREFIX}ss [desc]` - 📸 Manual screenshot\n"
                f"`{PREFIX}logs [N]` - View logs\n"
                f"`{PREFIX}lastlog [N]` - Recent logs"
            ),
            inline=False
        )
        
        embed.add_field(
            name="🔧 Utilities",
            value=(
                f"`{PREFIX}genpass [count]` - Generate passwords\n"
                f"`{PREFIX}test email:pass` - Test account"
            ),
            inline=False
        )
    
    embed.set_footer(text=f"Prefix: {PREFIX} | Owner: <@{SUPER_USER_ID}>")
    await ctx.send(embed=embed, ephemeral=not (is_super or is_auth))

# ============================================
# ERROR HANDLING & MAIN
# ============================================

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Missing argument: {error.param.name}", ephemeral=True)
    elif isinstance(error, commands.CheckFailure):
        pass
    else:
        await ctx.send(f"❌ Error: {str(error)[:100]}", ephemeral=True)

def main():
    if TOKEN == 'YOUR_BOT_TOKEN_HERE':
        print("❌ ERROR: Set your Discord bot token in main.py (line 15)")
        print("Get token from: https://discord.com/developers/applications")
        return
    
    print("=" * 50)
    print("Starting MS Account Password Changer Bot")
    print(f"Owner ID: {SUPER_USER_ID}")
    print(f"Prefix: {PREFIX}")
    print("Features:")
    print("  ✅ Stays in Discord (can use &ss anytime)")
    print("  ✅ Detailed step-by-step logs")
    print("  ✅ Manual screenshots with &ss")
    print("  ✅ Browser stays active during processing")
    print("=" * 50)
    
    try:
        bot.run(TOKEN)
    except discord.LoginFailure:
        print("❌ Invalid bot token!")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()